import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  Shield, 
  Activity, 
  TrendingUp, 
  FileText, 
  Settings,
  Database,
  UserPlus,
  AlertTriangle,
  CheckCircle
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("overview");

  // Mock data
  const adminInfo = {
    id: "ADM001KL",
    name: "Dr. Suresh Menon",
    role: "System Administrator",
    department: "Health IT Department, Kerala",
    lastLogin: "2024-01-20 09:30 AM"
  };

  const systemStats = {
    totalUsers: 1247,
    totalDoctors: 89,
    totalPatients: 1156,
    govOfficials: 12,
    activeToday: 423,
    systemUptime: "99.8%",
    pendingApprovals: 8,
    criticalAlerts: 2
  };

  const recentActivities = [
    {
      type: "new_registration",
      message: "New patient registered: Anil Kumar (TAHSU78901234)",
      timestamp: "2 minutes ago",
      priority: "normal"
    },
    {
      type: "doctor_verification",
      message: "Doctor verification pending: Dr. Kavitha Nair",
      timestamp: "15 minutes ago",
      priority: "high"
    },
    {
      type: "system_alert",
      message: "Database backup completed successfully",
      timestamp: "1 hour ago",
      priority: "normal"
    },
    {
      type: "security_alert",
      message: "Unusual login attempt blocked from IP: 192.168.1.100",
      timestamp: "2 hours ago",
      priority: "critical"
    }
  ];

  const pendingApprovals = [
    {
      id: 1,
      type: "Doctor Registration",
      name: "Dr. Kavitha Nair",
      hospital: "Medical College Hospital, Kozhikode",
      submittedDate: "2024-01-19",
      documents: "Complete"
    },
    {
      id: 2,
      type: "Hospital Partnership",
      name: "Aster Medicity",
      location: "Kochi",
      submittedDate: "2024-01-18",
      documents: "Under Review"
    }
  ];

  const handleLogout = () => {
    navigate("/");
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical": return "text-destructive";
      case "high": return "text-warning";
      default: return "text-muted-foreground";
    }
  };

  const getPriorityIcon = (type: string) => {
    switch (type) {
      case "security_alert": return <AlertTriangle className="w-4 h-4 text-destructive" />;
      case "doctor_verification": return <Shield className="w-4 h-4 text-warning" />;
      case "new_registration": return <UserPlus className="w-4 h-4 text-success" />;
      default: return <CheckCircle className="w-4 h-4 text-primary" />;
    }
  };

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="medical-shadow">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <Users className="w-8 h-8 text-primary" />
              <div>
                <p className="text-2xl font-bold">{systemStats.totalUsers}</p>
                <p className="text-sm text-muted-foreground">Total Users</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="medical-shadow">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <Shield className="w-8 h-8 text-secondary" />
              <div>
                <p className="text-2xl font-bold">{systemStats.totalDoctors}</p>
                <p className="text-sm text-muted-foreground">Doctors</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="medical-shadow">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <Activity className="w-8 h-8 text-accent" />
              <div>
                <p className="text-2xl font-bold">{systemStats.activeToday}</p>
                <p className="text-sm text-muted-foreground">Active Today</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="medical-shadow">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <TrendingUp className="w-8 h-8 text-success" />
              <div>
                <p className="text-2xl font-bold">{systemStats.systemUptime}</p>
                <p className="text-sm text-muted-foreground">System Uptime</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alert Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="medical-shadow border-l-4 border-l-warning">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-lg font-semibold">Pending Approvals</p>
                <p className="text-sm text-muted-foreground">
                  {systemStats.pendingApprovals} items require attention
                </p>
              </div>
              <Badge variant="outline" className="bg-warning/10">
                {systemStats.pendingApprovals}
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="medical-shadow border-l-4 border-l-destructive">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-lg font-semibold">Critical Alerts</p>
                <p className="text-sm text-muted-foreground">
                  {systemStats.criticalAlerts} security alerts
                </p>
              </div>
              <Badge variant="outline" className="bg-destructive/10">
                {systemStats.criticalAlerts}
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="medical-shadow">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity className="w-5 h-5 text-primary" />
            <span>Recent System Activity</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {recentActivities.map((activity, index) => (
            <div key={index} className="flex items-start space-x-3 p-3 border rounded-lg">
              {getPriorityIcon(activity.type)}
              <div className="flex-1">
                <p className={`text-sm ${getPriorityColor(activity.priority)}`}>
                  {activity.message}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {activity.timestamp}
                </p>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );

  const renderApprovals = () => (
    <Card className="medical-shadow">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <FileText className="w-5 h-5 text-primary" />
          <span>Pending Approvals</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {pendingApprovals.map((approval) => (
          <div key={approval.id} className="p-4 border rounded-lg space-y-3">
            <div className="flex justify-between items-start">
              <div>
                <p className="font-semibold">{approval.name}</p>
                <p className="text-sm text-muted-foreground">{approval.type}</p>
                <p className="text-sm text-muted-foreground">
                  {approval.hospital || approval.location}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Submitted: {approval.submittedDate}</p>
                <Badge 
                  variant={approval.documents === "Complete" ? "default" : "secondary"}
                  className={approval.documents === "Complete" ? "bg-success" : ""}
                >
                  {approval.documents}
                </Badge>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button size="sm" className="btn-medical">
                <CheckCircle className="w-4 h-4 mr-2" />
                Approve
              </Button>
              <Button size="sm" variant="outline">
                Review Documents
              </Button>
              <Button size="sm" variant="destructive">
                Reject
              </Button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );

  const renderSettings = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card className="medical-shadow">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Database className="w-5 h-5 text-primary" />
            <span>System Configuration</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Backup Frequency</label>
            <Input value="Daily at 2:00 AM" disabled />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Session Timeout</label>
            <Input value="30 minutes" disabled />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Max Login Attempts</label>
            <Input value="3 attempts" disabled />
          </div>
          <Button className="btn-medical w-full">
            <Settings className="w-4 h-4 mr-2" />
            Update Settings
          </Button>
        </CardContent>
      </Card>

      <Card className="medical-shadow">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="w-5 h-5 text-primary" />
            <span>Security Settings</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Two-Factor Authentication</label>
            <div className="flex items-center space-x-2">
              <Badge className="bg-success">Enabled</Badge>
              <span className="text-sm text-muted-foreground">All admin accounts</span>
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Password Policy</label>
            <div className="text-sm text-muted-foreground">
              <p>• Minimum 8 characters</p>
              <p>• Must include special characters</p>
              <p>• Changed every 90 days</p>
            </div>
          </div>
          <Button className="btn-medical w-full">
            <Shield className="w-4 h-4 mr-2" />
            Security Audit
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b medical-shadow">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Health+</h1>
              <p className="text-sm text-muted-foreground">Admin Portal</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="font-medium">{adminInfo.name}</p>
              <p className="text-sm text-muted-foreground">{adminInfo.role}</p>
              <p className="text-xs text-muted-foreground">ID: {adminInfo.id}</p>
            </div>
            <Button variant="outline" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white/60 backdrop-blur-sm border-b">
        <div className="max-w-7xl mx-auto px-4">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="h-auto p-0 bg-transparent">
              <TabsTrigger 
                value="overview" 
                className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
              >
                <Activity className="w-4 h-4 mr-2" />
                Overview
              </TabsTrigger>
              <TabsTrigger 
                value="approvals"
                className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
              >
                <FileText className="w-4 h-4 mr-2" />
                Approvals
              </TabsTrigger>
              <TabsTrigger 
                value="settings"
                className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
              >
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        <Tabs value={activeTab} className="w-full">
          <TabsContent value="overview">{renderOverview()}</TabsContent>
          <TabsContent value="approvals">{renderApprovals()}</TabsContent>
          <TabsContent value="settings">{renderSettings()}</TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default AdminDashboard;