import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Heart, 
  Calendar, 
  FileText, 
  MessageCircle, 
  Video, 
  User, 
  MapPin,
  Star,
  Phone,
  Bot,
  Clock,
  Search
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const PatientDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("home");
  const [chatMessage, setChatMessage] = useState("");
  const [citySearch, setCitySearch] = useState("");

  // Mock data
  const patientInfo = {
    id: "TAHSU56775556",
    name: "Ravi Kumar",
    age: 28,
    bloodGroup: "B+",
    state: "Tamil Nadu"
  };

  const mockDoctors = [
    {
      id: 1,
      name: "Dr. Priya Sharma",
      specialization: "General Medicine",
      experience: "8 years",
      rating: 4.8,
      reviews: 245,
      phone: "+91 98765 43210",
      distance: "2.3 km",
      hospital: "Government General Hospital, Kochi"
    },
    {
      id: 2,
      name: "Dr. Rajesh Nair",
      specialization: "Cardiology",
      experience: "12 years",
      rating: 4.9,
      reviews: 180,
      phone: "+91 98765 43211",
      distance: "3.1 km",
      hospital: "Medical College Hospital, Thiruvananthapuram"
    }
  ];

  const keralaCities = [
    "Thiruvananthapuram", "Kochi", "Kozhikode", "Thrissur", "Kollam", 
    "Palakkad", "Alappuzha", "Kannur", "Kasaragod", "Pathanamthitta"
  ];

  const healthRecords = [
    {
      date: "2024-01-15",
      doctor: "Dr. Priya Sharma",
      diagnosis: "Mild fever and cough",
      treatment: "Prescribed medication for viral infection",
      status: "Recovered"
    },
    {
      date: "2024-01-08",
      doctor: "Dr. Rajesh Nair",
      diagnosis: "Routine checkup",
      treatment: "Blood pressure and general health assessment",
      status: "Normal"
    }
  ];

  const handleLogout = () => {
    navigate("/");
  };

  const renderAINurse = () => (
    <Card className="medical-shadow">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Bot className="w-5 h-5 text-primary" />
          <span>AI Health Assistant</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-muted/50 p-4 rounded-lg">
          <p className="text-sm text-muted-foreground mb-2">AI Nurse:</p>
          <p>Hello {patientInfo.name}! I can help you find the right doctor or hospital. What symptoms are you experiencing?</p>
        </div>
        
        <div className="flex space-x-2">
          <Input
            value={chatMessage}
            onChange={(e) => setChatMessage(e.target.value)}
            placeholder="Describe your symptoms..."
          />
          <Button className="btn-medical">
            <MessageCircle className="w-4 h-4" />
          </Button>
        </div>

        <div className="space-y-2">
          <p className="text-sm font-medium">Recommended Doctors:</p>
          {mockDoctors.slice(0, 2).map((doctor) => (
            <div key={doctor.id} className="p-3 border rounded-lg space-y-2">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-medium">{doctor.name}</p>
                  <p className="text-sm text-muted-foreground">{doctor.specialization}</p>
                  <p className="text-sm text-muted-foreground">{doctor.hospital}</p>
                </div>
                <div className="text-right">
                  <div className="flex items-center space-x-1">
                    <Star className="w-3 h-3 text-yellow-500 fill-current" />
                    <span className="text-sm">{doctor.rating}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{doctor.distance}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Phone className="w-3 h-3" />
                <span>{doctor.phone}</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  const renderAppointments = () => (
    <div className="space-y-6">
      <Tabs defaultValue="in-person" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="in-person">In-Person Consult</TabsTrigger>
          <TabsTrigger value="online">Online Consult</TabsTrigger>
        </TabsList>
        
        <TabsContent value="in-person" className="space-y-4">
          <Card className="medical-shadow">
            <CardHeader>
              <CardTitle>Available Doctors</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {mockDoctors.map((doctor) => (
                <div key={doctor.id} className="p-4 border rounded-lg space-y-3">
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <h3 className="font-semibold">{doctor.name}</h3>
                      <p className="text-sm text-muted-foreground">{doctor.specialization}</p>
                      <p className="text-sm text-muted-foreground">Experience: {doctor.experience}</p>
                      <p className="text-sm text-muted-foreground">{doctor.hospital}</p>
                    </div>
                    <div className="text-right space-y-1">
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-500 fill-current" />
                        <span className="text-sm font-medium">{doctor.rating}</span>
                        <span className="text-xs text-muted-foreground">({doctor.reviews} reviews)</span>
                      </div>
                      <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                        <MapPin className="w-3 h-3" />
                        <span>{doctor.distance}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    <span>{doctor.phone}</span>
                  </div>
                  <Button className="w-full btn-medical">
                    <Calendar className="w-4 h-4 mr-2" />
                    Book Appointment
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="online" className="space-y-4">
          <Card className="medical-shadow">
            <CardHeader>
              <CardTitle>Select City</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  value={citySearch}
                  onChange={(e) => setCitySearch(e.target.value)}
                  placeholder="Search Kerala cities..."
                  className="pl-9"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                {keralaCities
                  .filter(city => city.toLowerCase().includes(citySearch.toLowerCase()))
                  .map((city) => (
                    <Button 
                      key={city} 
                      variant="outline" 
                      className="justify-start"
                      onClick={() => {}}
                    >
                      <MapPin className="w-4 h-4 mr-2" />
                      {city}
                    </Button>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );

  const renderHealthRecords = () => (
    <Card className="medical-shadow">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <FileText className="w-5 h-5 text-primary" />
          <span>Health Records</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {healthRecords.map((record, index) => (
          <div key={index} className="p-4 border rounded-lg space-y-2">
            <div className="flex justify-between items-start">
              <div className="space-y-1">
                <p className="font-medium">{record.diagnosis}</p>
                <p className="text-sm text-muted-foreground">Dr. {record.doctor}</p>
                <p className="text-sm text-muted-foreground">{record.treatment}</p>
              </div>
              <div className="text-right space-y-1">
                <p className="text-sm text-muted-foreground">{record.date}</p>
                <Badge 
                  variant={record.status === "Recovered" ? "default" : "secondary"}
                  className={record.status === "Recovered" ? "bg-success" : ""}
                >
                  {record.status}
                </Badge>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b medical-shadow">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 medical-gradient rounded-lg flex items-center justify-center">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Health+</h1>
              <p className="text-sm text-muted-foreground">Patient Portal</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="font-medium">{patientInfo.name}</p>
              <p className="text-sm text-muted-foreground">ID: {patientInfo.id}</p>
            </div>
            <Button variant="outline" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white/60 backdrop-blur-sm border-b">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex space-x-8">
            {[
              { key: "home", label: "Home", icon: Heart },
              { key: "appointments", label: "Appointments", icon: Calendar },
              { key: "records", label: "Health Records", icon: FileText }
            ].map(({ key, label, icon: Icon }) => (
              <button
                key={key}
                onClick={() => setActiveTab(key)}
                className={`flex items-center space-x-2 px-4 py-3 border-b-2 transition-colors ${
                  activeTab === key 
                    ? "border-primary text-primary" 
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === "home" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="medical-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3">
                    <User className="w-8 h-8 text-primary" />
                    <div>
                      <p className="font-medium">{patientInfo.name}</p>
                      <p className="text-sm text-muted-foreground">Age: {patientInfo.age} • {patientInfo.bloodGroup}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="medical-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3">
                    <MapPin className="w-8 h-8 text-secondary" />
                    <div>
                      <p className="font-medium">From {patientInfo.state}</p>
                      <p className="text-sm text-muted-foreground">Currently in Kerala</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="medical-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3">
                    <Clock className="w-8 h-8 text-accent" />
                    <div>
                      <p className="font-medium">Last Visit</p>
                      <p className="text-sm text-muted-foreground">Jan 15, 2024</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            {renderAINurse()}
          </div>
        )}

        {activeTab === "appointments" && renderAppointments()}
        {activeTab === "records" && renderHealthRecords()}
      </main>
    </div>
  );
};

export default PatientDashboard;