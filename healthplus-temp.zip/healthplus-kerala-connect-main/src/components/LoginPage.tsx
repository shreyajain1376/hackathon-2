import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Heart, Shield, Users, Building2 } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface LoginForm {
  userType: string;
  userId: string;
  password: string;
}

const userTypes = [
  { value: "patient", label: "Patient", icon: Heart, color: "text-primary" },
  { value: "doctor", label: "Doctor", icon: Shield, color: "text-secondary" },
  { value: "admin", label: "Administrator", icon: Users, color: "text-accent" },
  { value: "government", label: "Government Official", icon: Building2, color: "text-warning" }
];

import heroBackground from "@/assets/health-hero-bg.jpg";

export const LoginPage = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState<LoginForm>({
    userType: "",
    userId: "",
    password: ""
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock login - redirect based on user type
    switch(form.userType) {
      case "patient":
        navigate("/patient-dashboard");
        break;
      case "doctor":
        navigate("/doctor-dashboard");
        break;
      case "admin":
        navigate("/admin-dashboard");
        break;
      case "government":
        navigate("/government-dashboard");
        break;
    }
  };

  const selectedUserType = userTypes.find(type => type.value === form.userType);

  return (
    <div 
      className="min-h-screen bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5 flex items-center justify-center p-4 relative overflow-hidden"
      style={{
        backgroundImage: `linear-gradient(rgba(255, 255, 255, 0.95), rgba(255, 255, 255, 0.85)), url(${heroBackground})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      <div className="w-full max-w-md space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-10 h-10 medical-gradient rounded-lg flex items-center justify-center">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">Health+</h1>
          </div>
          <p className="text-muted-foreground">Digital Health Records for Kerala</p>
        </div>

        {/* Login Card */}
        <Card className="medical-shadow">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl text-center">Sign In</CardTitle>
            <p className="text-center text-muted-foreground">
              Access your health records securely
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              {/* User Type Selection */}
              <div className="space-y-2">
                <Label htmlFor="userType">Login as</Label>
                <Select 
                  value={form.userType} 
                  onValueChange={(value) => setForm(prev => ({ ...prev, userType: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select your role" />
                  </SelectTrigger>
                  <SelectContent>
                    {userTypes.map((type) => {
                      const Icon = type.icon;
                      return (
                        <SelectItem key={type.value} value={type.value}>
                          <div className="flex items-center space-x-2">
                            <Icon className={`w-4 h-4 ${type.color}`} />
                            <span>{type.label}</span>
                          </div>
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>

              {/* User ID */}
              <div className="space-y-2">
                <Label htmlFor="userId">
                  {selectedUserType ? `${selectedUserType.label} ID` : "User ID"}
                </Label>
                <Input
                  id="userId"
                  type="text"
                  value={form.userId}
                  onChange={(e) => setForm(prev => ({ ...prev, userId: e.target.value }))}
                  placeholder={selectedUserType ? `Enter your ${selectedUserType.label.toLowerCase()} ID` : "Enter your ID"}
                  required
                />
              </div>

              {/* Password */}
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={form.password}
                  onChange={(e) => setForm(prev => ({ ...prev, password: e.target.value }))}
                  placeholder="Enter your password"
                  required
                />
              </div>

              {/* Login Button */}
              <Button type="submit" className="w-full btn-medical">
                Sign In
              </Button>
            </form>

            {/* Register Link */}
            <div className="mt-6 text-center">
              <p className="text-sm text-muted-foreground">
                New patient?{" "}
                <Button 
                  variant="link" 
                  className="p-0 h-auto text-primary hover:text-primary-dark"
                  onClick={() => navigate("/register")}
                >
                  Register here
                </Button>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center text-xs text-muted-foreground">
          <p>Powered by Health+ • Secure • Compliant</p>
        </div>
      </div>
    </div>
  );
};