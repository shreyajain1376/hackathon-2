import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Heart, ArrowLeft, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

interface RegistrationForm {
  name: string;
  age: string;
  dateOfBirth: string;
  fromState: string;
  dateEnteredKerala: string;
  email: string;
  bloodGroup: string;
  height: string;
  weight: string;
  diseases: {
    asthma: boolean;
    diabetes: boolean;
    cancer: boolean;
    other: string;
  };
  aadharNo: string;
  mobileNo: string;
  otp: string;
}

const states = [
  "Andhra Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", 
  "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Madhya Pradesh", 
  "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", 
  "Punjab", "Rajasthan", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", 
  "Uttarakhand", "West Bengal"
];

const bloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

export const RegisterPage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [otpSent, setOtpSent] = useState(false);
  const [patientId, setPatientId] = useState("");
  const [form, setForm] = useState<RegistrationForm>({
    name: "",
    age: "",
    dateOfBirth: "",
    fromState: "",
    dateEnteredKerala: "",
    email: "",
    bloodGroup: "",
    height: "",
    weight: "",
    diseases: {
      asthma: false,
      diabetes: false,
      cancer: false,
      other: ""
    },
    aadharNo: "",
    mobileNo: "",
    otp: ""
  });

  const generatePatientId = () => {
    return "TAHSU" + Math.random().toString().substr(2, 8);
  };

  const handleSendOtp = () => {
    if (!form.mobileNo) {
      toast({
        title: "Error",
        description: "Please enter your mobile number",
        variant: "destructive",
      });
      return;
    }
    setOtpSent(true);
    toast({
      title: "OTP Sent",
      description: "Verification code sent to your mobile number",
    });
  };

  const handleVerifyOtp = () => {
    if (form.otp === "123456") { // Mock OTP verification
      const newPatientId = generatePatientId();
      setPatientId(newPatientId);
      setStep(2);
      toast({
        title: "Registration Successful!",
        description: `Your Patient ID: ${newPatientId}`,
      });
    } else {
      toast({
        title: "Invalid OTP",
        description: "Please enter the correct verification code",
        variant: "destructive",
      });
    }
  };

  if (step === 2) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5 flex items-center justify-center p-4">
        <Card className="w-full max-w-md medical-shadow">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mb-4">
              <CheckCircle className="w-8 h-8 text-success" />
            </div>
            <CardTitle className="text-2xl">Registration Complete!</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center space-y-2">
              <p className="text-muted-foreground">Your unique Patient ID:</p>
              <div className="p-4 bg-primary/10 rounded-lg">
                <p className="text-xl font-bold text-primary">{patientId}</p>
              </div>
              <p className="text-sm text-muted-foreground">
                Please save this ID for future logins
              </p>
            </div>
            
            <div className="space-y-3">
              <Label>Set Your Password</Label>
              <Input type="password" placeholder="Enter password" />
              <Input type="password" placeholder="Confirm password" />
            </div>

            <Button 
              onClick={() => navigate("/")} 
              className="w-full btn-medical"
            >
              Complete Registration
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-10 h-10 medical-gradient rounded-lg flex items-center justify-center">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">Health+</h1>
          </div>
          <p className="text-muted-foreground">Patient Registration</p>
        </div>

        <Card className="medical-shadow">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate("/")}
                className="p-2"
              >
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <CardTitle>New Patient Registration</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Personal Information */}
              <div className="space-y-2">
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  value={form.name}
                  onChange={(e) => setForm(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter full name"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="age">Age *</Label>
                <Input
                  id="age"
                  type="number"
                  value={form.age}
                  onChange={(e) => setForm(prev => ({ ...prev, age: e.target.value }))}
                  placeholder="Enter age"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="dob">Date of Birth *</Label>
                <Input
                  id="dob"
                  type="date"
                  value={form.dateOfBirth}
                  onChange={(e) => setForm(prev => ({ ...prev, dateOfBirth: e.target.value }))}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="fromState">From State *</Label>
                <Select 
                  value={form.fromState} 
                  onValueChange={(value) => setForm(prev => ({ ...prev, fromState: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select state" />
                  </SelectTrigger>
                  <SelectContent>
                    {states.map((state) => (
                      <SelectItem key={state} value={state}>{state}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="entryDate">Date Entered Kerala *</Label>
                <Input
                  id="entryDate"
                  type="date"
                  value={form.dateEnteredKerala}
                  onChange={(e) => setForm(prev => ({ ...prev, dateEnteredKerala: e.target.value }))}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email (Optional)</Label>
                <Input
                  id="email"
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="Enter email"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bloodGroup">Blood Group *</Label>
                <Select 
                  value={form.bloodGroup} 
                  onValueChange={(value) => setForm(prev => ({ ...prev, bloodGroup: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select blood group" />
                  </SelectTrigger>
                  <SelectContent>
                    {bloodGroups.map((group) => (
                      <SelectItem key={group} value={group}>{group}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="height">Height (cm) *</Label>
                <Input
                  id="height"
                  type="number"
                  value={form.height}
                  onChange={(e) => setForm(prev => ({ ...prev, height: e.target.value }))}
                  placeholder="Enter height"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="weight">Weight (kg) *</Label>
                <Input
                  id="weight"
                  type="number"
                  value={form.weight}
                  onChange={(e) => setForm(prev => ({ ...prev, weight: e.target.value }))}
                  placeholder="Enter weight"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="aadhar">Aadhar Number *</Label>
                <Input
                  id="aadhar"
                  value={form.aadharNo}
                  onChange={(e) => setForm(prev => ({ ...prev, aadharNo: e.target.value }))}
                  placeholder="Enter Aadhar number"
                  required
                />
              </div>
            </div>

            {/* Medical History */}
            <div className="space-y-4">
              <Label className="text-base font-semibold">Medical History</Label>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="asthma"
                    checked={form.diseases.asthma}
                    onCheckedChange={(checked) => 
                      setForm(prev => ({ 
                        ...prev, 
                        diseases: { ...prev.diseases, asthma: checked as boolean }
                      }))
                    }
                  />
                  <Label htmlFor="asthma">Asthma</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="diabetes"
                    checked={form.diseases.diabetes}
                    onCheckedChange={(checked) => 
                      setForm(prev => ({ 
                        ...prev, 
                        diseases: { ...prev.diseases, diabetes: checked as boolean }
                      }))
                    }
                  />
                  <Label htmlFor="diabetes">Diabetes</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="cancer"
                    checked={form.diseases.cancer}
                    onCheckedChange={(checked) => 
                      setForm(prev => ({ 
                        ...prev, 
                        diseases: { ...prev.diseases, cancer: checked as boolean }
                      }))
                    }
                  />
                  <Label htmlFor="cancer">Cancer</Label>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="otherDiseases">Other Medical Conditions</Label>
                  <Textarea
                    id="otherDiseases"
                    value={form.diseases.other}
                    onChange={(e) => 
                      setForm(prev => ({ 
                        ...prev, 
                        diseases: { ...prev.diseases, other: e.target.value }
                      }))
                    }
                    placeholder="Specify any other medical conditions"
                  />
                </div>
              </div>
            </div>

            {/* Mobile Verification */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="mobile">Mobile Number *</Label>
                <div className="flex space-x-2">
                  <Input
                    id="mobile"
                    value={form.mobileNo}
                    onChange={(e) => setForm(prev => ({ ...prev, mobileNo: e.target.value }))}
                    placeholder="Enter mobile number"
                    required
                  />
                  <Button 
                    type="button"
                    onClick={handleSendOtp}
                    variant="outline"
                    disabled={otpSent}
                  >
                    {otpSent ? "Sent" : "Send OTP"}
                  </Button>
                </div>
              </div>

              {otpSent && (
                <div className="space-y-2">
                  <Label htmlFor="otp">Enter OTP *</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="otp"
                      value={form.otp}
                      onChange={(e) => setForm(prev => ({ ...prev, otp: e.target.value }))}
                      placeholder="Enter 6-digit OTP"
                      required
                    />
                    <Button 
                      onClick={handleVerifyOtp}
                      className="btn-medical"
                    >
                      Verify
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">Demo OTP: 123456</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};