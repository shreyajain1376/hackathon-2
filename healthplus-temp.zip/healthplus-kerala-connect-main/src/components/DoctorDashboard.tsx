import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { 
  Shield, 
  Search, 
  User, 
  FileText, 
  Star, 
  Calendar,
  Clock,
  Phone,
  Edit,
  Save
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const DoctorDashboard = () => {
  const navigate = useNavigate();
  const [patientSearch, setPatientSearch] = useState("");
  const [selectedPatient, setSelectedPatient] = useState<any>(null);
  const [isUpdating, setIsUpdating] = useState(false);
  const [updateNotes, setUpdateNotes] = useState("");

  // Mock data
  const doctorInfo = {
    id: "DOC001KCH",
    name: "Dr. Priya Sharma",
    specialization: "General Medicine",
    hospital: "Government General Hospital, Kochi",
    license: "KL/MED/2015/001234"
  };

  const appointments = [
    {
      id: 1,
      patientId: "TAHSU56775556",
      patientName: "Ravi Kumar",
      date: "2024-01-20",
      time: "10:30 AM",
      type: "Follow-up",
      status: "completed",
      feedback: "Doctor was very helpful and explained everything clearly. Satisfied with the treatment."
    },
    {
      id: 2,
      patientId: "TAHSU78901234",
      patientName: "Meera Nair",
      date: "2024-01-20",
      time: "11:00 AM",
      type: "Consultation",
      status: "scheduled",
      feedback: ""
    },
    {
      id: 3,
      patientId: "TAHSU45678901",
      patientName: "Suresh Kumar",
      date: "2024-01-19",
      time: "2:00 PM",
      type: "Consultation",
      status: "completed",
      feedback: "Excellent doctor. Very patient and thorough examination. Highly recommended."
    }
  ];

  const patientRecords = {
    "TAHSU56775556": {
      name: "Ravi Kumar",
      age: 28,
      bloodGroup: "B+",
      phone: "+91 98765 43210",
      fromState: "Tamil Nadu",
      currentConditions: ["Hypertension"],
      allergies: ["Penicillin"],
      lastVisit: "2024-01-15",
      healthHistory: [
        {
          date: "2024-01-15",
          diagnosis: "Mild fever and cough",
          prescription: "Paracetamol 500mg, Cough syrup",
          notes: "Viral infection, advised rest and hydration"
        },
        {
          date: "2024-01-08",
          diagnosis: "Routine checkup",
          prescription: "Multivitamins",
          notes: "General health assessment, all parameters normal"
        }
      ],
      labReports: [
        {
          date: "2024-01-08",
          type: "Complete Blood Count",
          results: "Normal ranges for all parameters",
          file: "cbc_report_080124.pdf"
        }
      ]
    }
  };

  const handlePatientSearch = (patientId: string, patientName: string) => {
    const patient = patientRecords[patientId as keyof typeof patientRecords];
    if (patient) {
      setSelectedPatient({
        id: patientId,
        ...patient
      });
    }
  };

  const handleUpdateRecord = () => {
    if (updateNotes.trim()) {
      // Mock update functionality
      console.log("Updating patient record:", selectedPatient?.id, updateNotes);
      setIsUpdating(false);
      setUpdateNotes("");
    }
  };

  const handleLogout = () => {
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b medical-shadow">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Health+</h1>
              <p className="text-sm text-muted-foreground">Doctor Portal</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="font-medium">{doctorInfo.name}</p>
              <p className="text-sm text-muted-foreground">{doctorInfo.specialization}</p>
              <p className="text-xs text-muted-foreground">ID: {doctorInfo.id}</p>
            </div>
            <Button variant="outline" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        {/* Doctor Info Card */}
        <Card className="medical-shadow">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center space-x-3">
                <Shield className="w-8 h-8 text-secondary" />
                <div>
                  <p className="font-medium">{doctorInfo.hospital}</p>
                  <p className="text-sm text-muted-foreground">Licensed Practitioner</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <FileText className="w-8 h-8 text-primary" />
                <div>
                  <p className="font-medium">License No.</p>
                  <p className="text-sm text-muted-foreground">{doctorInfo.license}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <User className="w-8 h-8 text-accent" />
                <div>
                  <p className="font-medium">Active Patients</p>
                  <p className="text-sm text-muted-foreground">247 registered</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Patient Search */}
        <Card className="medical-shadow">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Search className="w-5 h-5 text-primary" />
              <span>Patient Lookup</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex space-x-2">
              <Input
                placeholder="Enter Patient ID (e.g., TAHSU56775556)"
                value={patientSearch}
                onChange={(e) => setPatientSearch(e.target.value)}
              />
              <Button 
                onClick={() => handlePatientSearch(patientSearch, "Sample Patient")}
                className="btn-medical"
              >
                <Search className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Demo Patient ID: TAHSU56775556
            </p>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Appointments */}
          <Card className="medical-shadow">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="w-5 h-5 text-primary" />
                <span>Recent Appointments</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {appointments.map((appointment) => (
                <div key={appointment.id} className="p-4 border rounded-lg space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium">{appointment.patientName}</p>
                      <p className="text-sm text-muted-foreground">ID: {appointment.patientId}</p>
                      <p className="text-sm text-muted-foreground">{appointment.type}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{appointment.date}</p>
                      <p className="text-sm text-muted-foreground">{appointment.time}</p>
                      <Badge 
                        variant={appointment.status === "completed" ? "default" : "secondary"}
                        className={appointment.status === "completed" ? "bg-success" : ""}
                      >
                        {appointment.status}
                      </Badge>
                    </div>
                  </div>
                  
                  {appointment.feedback && (
                    <div className="bg-muted/50 p-3 rounded-lg">
                      <div className="flex items-center space-x-2 mb-2">
                        <Star className="w-4 h-4 text-yellow-500 fill-current" />
                        <span className="text-sm font-medium">Patient Feedback:</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{appointment.feedback}</p>
                    </div>
                  )}
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handlePatientSearch(appointment.patientId, appointment.patientName)}
                  >
                    View Records
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Patient Records */}
          <Card className="medical-shadow">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <FileText className="w-5 h-5 text-primary" />
                <span>Patient Health Records</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedPatient ? (
                <div className="space-y-4">
                  {/* Patient Info */}
                  <div className="p-4 bg-muted/30 rounded-lg">
                    <h3 className="font-semibold text-lg mb-2">{selectedPatient.name}</h3>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <p><span className="font-medium">Age:</span> {selectedPatient.age}</p>
                      <p><span className="font-medium">Blood Group:</span> {selectedPatient.bloodGroup}</p>
                      <p><span className="font-medium">From:</span> {selectedPatient.fromState}</p>
                      <p><span className="font-medium">Phone:</span> {selectedPatient.phone}</p>
                    </div>
                  </div>

                  {/* Current Conditions */}
                  <div>
                    <h4 className="font-medium mb-2">Current Conditions</h4>
                    <div className="flex space-x-2">
                      {selectedPatient.currentConditions.map((condition: string, index: number) => (
                        <Badge key={index} variant="outline">{condition}</Badge>
                      ))}
                    </div>
                  </div>

                  {/* Health History */}
                  <div>
                    <h4 className="font-medium mb-2">Recent Visits</h4>
                    <div className="space-y-2">
                      {selectedPatient.healthHistory.map((record: any, index: number) => (
                        <div key={index} className="p-3 border rounded-lg">
                          <div className="flex justify-between items-start mb-2">
                            <p className="font-medium">{record.diagnosis}</p>
                            <p className="text-sm text-muted-foreground">{record.date}</p>
                          </div>
                          <p className="text-sm text-muted-foreground mb-1">
                            <span className="font-medium">Treatment:</span> {record.prescription}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            <span className="font-medium">Notes:</span> {record.notes}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Lab Reports */}
                  <div>
                    <h4 className="font-medium mb-2">Lab Reports</h4>
                    {selectedPatient.labReports.map((report: any, index: number) => (
                      <div key={index} className="p-3 border rounded-lg">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="font-medium">{report.type}</p>
                            <p className="text-sm text-muted-foreground">{report.results}</p>
                            <p className="text-xs text-muted-foreground">{report.date}</p>
                          </div>
                          <Button variant="outline" size="sm">
                            View Report
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Update Records */}
                  <div className="border-t pt-4">
                    {!isUpdating ? (
                      <Button 
                        onClick={() => setIsUpdating(true)}
                        className="btn-medical w-full"
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Update Patient Record
                      </Button>
                    ) : (
                      <div className="space-y-3">
                        <Textarea
                          value={updateNotes}
                          onChange={(e) => setUpdateNotes(e.target.value)}
                          placeholder="Enter consultation notes, new diagnosis, prescription changes..."
                          rows={4}
                        />
                        <div className="flex space-x-2">
                          <Button 
                            onClick={handleUpdateRecord}
                            className="btn-medical flex-1"
                          >
                            <Save className="w-4 h-4 mr-2" />
                            Save Update
                          </Button>
                          <Button 
                            variant="outline" 
                            onClick={() => setIsUpdating(false)}
                            className="flex-1"
                          >
                            Cancel
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Search for a patient to view their records</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default DoctorDashboard;