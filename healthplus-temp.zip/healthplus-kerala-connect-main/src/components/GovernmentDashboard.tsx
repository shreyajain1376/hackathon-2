import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Building2, 
  Search, 
  Users, 
  FileText, 
  Star, 
  MapPin,
  Phone,
  Calendar,
  TrendingUp,
  Activity,
  Shield
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const GovernmentDashboard = () => {
  const navigate = useNavigate();
  const [patientSearch, setPatientSearch] = useState("");
  const [selectedPatient, setSelectedPatient] = useState<any>(null);

  // Mock data
  const govOfficialInfo = {
    id: "GOV001KL",
    name: "Rajesh Pillai",
    position: "Health Monitoring Officer",
    department: "Department of Health, Kerala",
    jurisdiction: "Kochi District"
  };

  const patientDatabase = {
    "TAHSU56775556": {
      personalDetails: {
        name: "Ravi Kumar",
        age: 28,
        mobile: "+91 98765 43210",
        height: "175 cm",
        weight: "70 kg",
        bloodGroup: "B+",
        fromState: "Tamil Nadu",
        entryDate: "2023-08-15",
        aadhar: "XXXX-XXXX-5556"
      },
      medicalInfo: {
        diseases: ["Hypertension", "Migraine"],
        allergies: ["Penicillin"],
        emergencyContact: "+91 98765 43211"
      },
      healthRecords: [
        {
          date: "2024-01-15",
          doctor: "Dr. Priya Sharma",
          hospital: "Govt. General Hospital, Kochi",
          diagnosis: "Mild fever and cough",
          treatment: "Prescribed medication for viral infection",
          status: "Recovered"
        },
        {
          date: "2024-01-08",
          doctor: "Dr. Rajesh Nair",
          hospital: "Medical College Hospital",
          diagnosis: "Routine checkup",
          treatment: "Blood pressure monitoring",
          status: "Normal"
        }
      ],
      appointmentHistory: [
        {
          date: "2024-01-15",
          doctor: "Dr. Priya Sharma",
          type: "Follow-up",
          feedback: {
            rating: 4.8,
            comment: "Doctor was very helpful and explained everything clearly."
          }
        },
        {
          date: "2024-01-08",
          doctor: "Dr. Rajesh Nair",
          type: "Consultation",
          feedback: {
            rating: 4.9,
            comment: "Excellent doctor. Very thorough examination."
          }
        }
      ]
    }
  };

  const migrantWorkerStats = {
    total: 1247,
    registered: 1189,
    activePatients: 856,
    criticalCases: 12,
    newRegistrations: 23
  };

  const handlePatientSearch = () => {
    const patient = patientDatabase[patientSearch as keyof typeof patientDatabase];
    if (patient) {
      setSelectedPatient({
        id: patientSearch,
        ...patient
      });
    }
  };

  const handleLogout = () => {
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b medical-shadow">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-warning rounded-lg flex items-center justify-center">
              <Building2 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Health+</h1>
              <p className="text-sm text-muted-foreground">Government Portal</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="font-medium">{govOfficialInfo.name}</p>
              <p className="text-sm text-muted-foreground">{govOfficialInfo.position}</p>
              <p className="text-xs text-muted-foreground">ID: {govOfficialInfo.id}</p>
            </div>
            <Button variant="outline" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        {/* Official Info Card */}
        <Card className="medical-shadow">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center space-x-3">
                <Building2 className="w-8 h-8 text-warning" />
                <div>
                  <p className="font-medium">{govOfficialInfo.department}</p>
                  <p className="text-sm text-muted-foreground">Authorized Official</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="w-8 h-8 text-primary" />
                <div>
                  <p className="font-medium">Jurisdiction</p>
                  <p className="text-sm text-muted-foreground">{govOfficialInfo.jurisdiction}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Shield className="w-8 h-8 text-accent" />
                <div>
                  <p className="font-medium">Access Level</p>
                  <p className="text-sm text-muted-foreground">Full Administrative Rights</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Statistics Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
          <Card className="medical-shadow">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <Users className="w-8 h-8 text-primary" />
                <div>
                  <p className="text-2xl font-bold">{migrantWorkerStats.total}</p>
                  <p className="text-sm text-muted-foreground">Total Workers</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="medical-shadow">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <FileText className="w-8 h-8 text-accent" />
                <div>
                  <p className="text-2xl font-bold">{migrantWorkerStats.registered}</p>
                  <p className="text-sm text-muted-foreground">Registered</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="medical-shadow">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <Activity className="w-8 h-8 text-secondary" />
                <div>
                  <p className="text-2xl font-bold">{migrantWorkerStats.activePatients}</p>
                  <p className="text-sm text-muted-foreground">Active Patients</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="medical-shadow">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <TrendingUp className="w-8 h-8 text-warning" />
                <div>
                  <p className="text-2xl font-bold text-destructive">{migrantWorkerStats.criticalCases}</p>
                  <p className="text-sm text-muted-foreground">Critical Cases</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="medical-shadow">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <Calendar className="w-8 h-8 text-success" />
                <div>
                  <p className="text-2xl font-bold text-success">{migrantWorkerStats.newRegistrations}</p>
                  <p className="text-sm text-muted-foreground">New This Week</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Patient Search */}
          <Card className="medical-shadow">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Search className="w-5 h-5 text-primary" />
                <span>Patient Information Lookup</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex space-x-2">
                <Input
                  placeholder="Enter Patient ID and Name"
                  value={patientSearch}
                  onChange={(e) => setPatientSearch(e.target.value)}
                />
                <Button 
                  onClick={handlePatientSearch}
                  className="btn-medical"
                >
                  <Search className="w-4 h-4" />
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Demo Patient ID: TAHSU56775556
              </p>
            </CardContent>
          </Card>

          {/* Patient Details */}
          <Card className="medical-shadow">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <FileText className="w-5 h-5 text-primary" />
                <span>Patient Overview</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedPatient ? (
                <div className="space-y-6">
                  {/* Personal Details */}
                  <div>
                    <h3 className="font-semibold text-lg mb-3">{selectedPatient.personalDetails.name}</h3>
                    <div className="grid grid-cols-2 gap-2 text-sm bg-muted/30 p-4 rounded-lg">
                      <p><span className="font-medium">Age:</span> {selectedPatient.personalDetails.age}</p>
                      <p><span className="font-medium">Mobile:</span> {selectedPatient.personalDetails.mobile}</p>
                      <p><span className="font-medium">Height:</span> {selectedPatient.personalDetails.height}</p>
                      <p><span className="font-medium">Weight:</span> {selectedPatient.personalDetails.weight}</p>
                      <p><span className="font-medium">Blood Group:</span> {selectedPatient.personalDetails.bloodGroup}</p>
                      <p><span className="font-medium">From:</span> {selectedPatient.personalDetails.fromState}</p>
                      <p><span className="font-medium">Entry Date:</span> {selectedPatient.personalDetails.entryDate}</p>
                      <p><span className="font-medium">Aadhar:</span> {selectedPatient.personalDetails.aadhar}</p>
                    </div>
                  </div>

                  {/* Medical Conditions */}
                  <div>
                    <h4 className="font-medium mb-2">Medical Conditions</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedPatient.medicalInfo.diseases.map((disease: string, index: number) => (
                        <Badge key={index} variant="outline" className="bg-warning/10">
                          {disease}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Recent Health Records */}
                  <div>
                    <h4 className="font-medium mb-2">Recent Health Records</h4>
                    <div className="space-y-2 max-h-32 overflow-y-auto">
                      {selectedPatient.healthRecords.map((record: any, index: number) => (
                        <div key={index} className="p-3 border rounded-lg text-sm">
                          <div className="flex justify-between items-start mb-1">
                            <p className="font-medium">{record.diagnosis}</p>
                            <p className="text-muted-foreground">{record.date}</p>
                          </div>
                          <p className="text-muted-foreground">Dr. {record.doctor}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Appointment History */}
                  <div>
                    <h4 className="font-medium mb-2">Doctor Appointments & Feedback</h4>
                    <div className="space-y-2">
                      {selectedPatient.appointmentHistory.map((appointment: any, index: number) => (
                        <div key={index} className="p-3 border rounded-lg">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <p className="font-medium">{appointment.doctor}</p>
                              <p className="text-sm text-muted-foreground">{appointment.type} • {appointment.date}</p>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Star className="w-4 h-4 text-yellow-500 fill-current" />
                              <span className="text-sm font-medium">{appointment.feedback.rating}</span>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground italic">
                            "{appointment.feedback.comment}"
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Search for a patient to view their complete profile</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default GovernmentDashboard;